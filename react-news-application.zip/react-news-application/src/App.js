import logo from './logo.svg';
import './App.css';
import NewsHeader from './components/NewsHeader';
import NewsManagers from './components/NewsManagers';

function App() {
  return (
    <div className="App">
      {/* <NewsHeader/> */}
      <NewsManagers/>
    </div>
  );
}

export default App;
